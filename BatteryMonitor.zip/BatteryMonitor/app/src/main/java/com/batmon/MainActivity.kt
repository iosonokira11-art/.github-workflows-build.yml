package com.batmon

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private var pendingId: String? = null
    private val tick = object : Runnable {
        override fun run() { render(); h.postDelayed(this, 5000) }
    }
    private val emojis = arrayOf("🎧", "🔊", "⌚", "📱", "💻", "⌨️", "🖱️", "🎮", "🚗", "❤️", "📷", "🕶️", "💡", "🖊️", "🔵")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(24))
        }
        col.addView(TextView(this).apply { text = "🔋 Monitor Batteria"; textSize = 24f })
        col.addView(TextView(this).apply {
            text = "Avvisi a 20%, 15%, 10%, 5% e allo spegnimento. Tocca un dispositivo per cambiare nome o icona."
            textSize = 13f; setPadding(0, dp(6), 0, dp(10))
        })
        col.addView(button("➕ Aggiungi widget alla home") { addWidget() })
        col.addView(button("⚙️ Disattiva ottimizzazione batteria") { ignoreBatteryOpt() })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0) }
        col.addView(list)
        col.addView(TextView(this).apply {
            text = "Realme: Impostazioni → App → Monitor Batteria → Utilizzo batteria → \"Nessuna restrizione\" e attiva \"Avvio automatico\", altrimenti il sistema può chiudere il servizio."
            textSize = 12f; setPadding(0, dp(16), 0, 0)
        })
        sv.addView(col)
        setContentView(sv)
        ensurePermissions()
    }

    private fun button(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    private fun ensurePermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) startMonitor() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        startMonitor()
    }

    private fun startMonitor() {
        try { startForegroundService(Intent(this, MonitorService::class.java)) }
        catch (e: Throwable) { Toast.makeText(this, "Impossibile avviare il servizio: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun render() {
        list.removeAllViews()
        for (e in Store.entries(this)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { options(e) }
                alpha = if (e.connected) 1f else 0.5f
            }
            if (e.image != null) {
                row.addView(ImageView(this).apply { setImageBitmap(e.image) },
                    LinearLayout.LayoutParams(dp(40), dp(40)))
            } else {
                row.addView(TextView(this).apply { text = e.emoji; textSize = 28f; gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(dp(40), dp(40)))
            }
            val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            mid.addView(TextView(this).apply { text = e.name; textSize = 16f })
            mid.addView(TextView(this).apply {
                textSize = 12f
                text = when {
                    !e.connected -> "Non connesso"
                    e.level < 0 -> "Connesso – batteria non comunicata"
                    e.charging -> "In carica"
                    else -> "Connesso"
                }
            })
            row.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply {
                text = if (e.level >= 0) "${e.level}%" else "—"; textSize = 18f
            })
            list.addView(row)
        }
        if (Store.entries(this).isEmpty())
            list.addView(TextView(this).apply { text = "Nessun dispositivo ancora rilevato…" })
    }

    private fun options(e: Entry) {
        AlertDialog.Builder(this).setTitle(e.name).setItems(
            arrayOf("✏️ Rinomina", "🙂 Scegli icona", "🖼️ Immagine dalla galleria", "↩️ Ripristina automatico")
        ) { _, w ->
            when (w) {
                0 -> rename(e)
                1 -> AlertDialog.Builder(this).setTitle("Icona").setItems(emojis) { _, i ->
                    Store.imgFile(this, e.id).delete()
                    Store.setEmoji(this, e.id, emojis[i]); changed()
                }.show()
                2 -> {
                    pendingId = e.id
                    startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 42)
                }
                3 -> {
                    Store.imgFile(this, e.id).delete()
                    Store.setEmoji(this, e.id, null); Store.setAlias(this, e.id, null); changed()
                }
            }
        }.show()
    }

    private fun rename(e: Entry) {
        val et = EditText(this).apply { setText(e.name) }
        AlertDialog.Builder(this).setTitle("Nome").setView(et)
            .setPositiveButton("OK") { _, _ -> Store.setAlias(this, e.id, et.text.toString()); changed() }
            .setNegativeButton("Annulla", null).show()
    }

    private fun changed() { BatteryWidget.updateAll(this); render() }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri: Uri = data?.data ?: return
        val id = pendingId ?: return
        if (req != 42 || res != RESULT_OK) return
        try {
            val src: Bitmap = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) } ?: return
            val s = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
            val out = Bitmap.createScaledBitmap(sq, 96, 96, true)
            FileOutputStream(Store.imgFile(this, id)).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            changed()
        } catch (e: Throwable) {
            Toast.makeText(this, "Immagine non valida", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addWidget() {
        val m = getSystemService(AppWidgetManager::class.java)
        if (m.isRequestPinAppWidgetSupported)
            m.requestPinAppWidget(ComponentName(this, BatteryWidget::class.java), null, null)
        else Toast.makeText(this, "Tieni premuto sulla home → Widget → Monitor Batteria", Toast.LENGTH_LONG).show()
    }

    private fun ignoreBatteryOpt() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Throwable) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
