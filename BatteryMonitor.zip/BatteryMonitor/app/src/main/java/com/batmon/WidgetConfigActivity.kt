package com.batmon

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class WidgetConfigActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        window.statusBarColor = 0xFF0B0D12.toInt()
        window.navigationBarColor = 0xFF0B0D12.toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@WidgetConfigActivity, 16), Ui.dp(this@WidgetConfigActivity, 36),
                Ui.dp(this@WidgetConfigActivity, 16), Ui.dp(this@WidgetConfigActivity, 24))
        }
        col.addView(TextView(this).apply { text = "Scegli il dispositivo"; textSize = 22f; setTextColor(Color.WHITE) })
        col.addView(TextView(this).apply {
            text = "Questo widget mostrerà un solo dispositivo."
            textSize = 13f; setTextColor(0xFF9CA3AF.toInt()); setPadding(0, Ui.dp(this@WidgetConfigActivity, 4), 0, Ui.dp(this@WidgetConfigActivity, 16))
        })
        val es = Store.entries(this)
        if (es.isEmpty()) {
            try { startForegroundService(Intent(this, MonitorService::class.java)) } catch (e: Throwable) { }
            col.addView(TextView(this).apply {
                text = "Nessun dispositivo rilevato. Apri prima l'app Monitor Batteria, concedi i permessi e riprova."
                setTextColor(0xFFF3F4F6.toInt())
            })
        }
        for (e in es) col.addView(Ui.card(this, e) {
            Store.setWidget(this, wid, e.id)
            BatteryWidget.update(this, AppWidgetManager.getInstance(this), wid)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
            finish()
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B0D12.toInt()); addView(col) })
    }
}
