package com.batmon

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews

class BatteryWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, BatteryWidget::class.java))
            for (id in ids) m.updateAppWidget(id, build(c))
        }

        private fun build(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.removeAllViews(R.id.colL)
            rv.removeAllViews(R.id.colR)
            val es = Store.entries(c).filter { it.connected && it.level >= 0 }
            es.forEachIndexed { i, e ->
                val r = RemoteViews(c.packageName, R.layout.widget_row)
                if (e.image != null) {
                    r.setImageViewBitmap(R.id.ico, e.image)
                    r.setViewVisibility(R.id.ico, View.VISIBLE)
                    r.setViewVisibility(R.id.emo, View.GONE)
                } else {
                    r.setTextViewText(R.id.emo, e.emoji)
                    r.setViewVisibility(R.id.emo, View.VISIBLE)
                    r.setViewVisibility(R.id.ico, View.GONE)
                }
                r.setTextViewText(R.id.pct, "${e.level}%" + if (e.charging) " ⚡" else "")
                r.setTextColor(R.id.pct, if (e.level <= 15) Color.parseColor("#FF6B6B") else Color.WHITE)
                rv.addView(if (i % 2 == 0) R.id.colL else R.id.colR, r)
            }
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, pi)
            return rv
        }
    }
}
