package com.batmon

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews

class BatteryWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) update(c, m, id)
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: Bundle) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        for (id in ids) Store.clearWidget(c, id)
    }

    companion object {
        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, BatteryWidget::class.java))) update(c, m, id)
        }

        fun update(c: Context, m: AppWidgetManager, id: Int) {
            val dev = Store.widgetDevice(c, id)
            val e = if (dev == null) null else Store.entries(c).firstOrNull { it.id == dev }
            val o = m.getAppWidgetOptions(id)
            val d = c.resources.displayMetrics.density
            var wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            var hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            if (wdp <= 0) wdp = 150
            if (hdp <= 0) hdp = 70
            var w = wdp * d
            var h = hdp * d
            val k = 600f / maxOf(w, h)
            if (k < 1f) { w *= k; h *= k }
            val bmp = Render.widget(c, e, maxOf(40, w.toInt()), maxOf(40, h.toInt()), d)

            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setImageViewBitmap(R.id.img, bmp)
            val intent = if (dev == null)
                Intent(c, WidgetConfigActivity::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            else Intent(c, MainActivity::class.java)
            rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(
                c, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            m.updateAppWidget(id, rv)
        }
    }
}
