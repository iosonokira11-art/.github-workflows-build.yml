package com.batmon

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

object Alerts {
    const val CH_ALERT = "battery_alerts"
    const val CH_MON = "battery_monitor"
    private val T = intArrayOf(20, 15, 10, 5)

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Avvisi batteria", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_MON, "Monitoraggio attivo", NotificationManager.IMPORTANCE_MIN)
        )
    }

    private fun send(c: Context, id: String, title: String, text: String) {
        val n = Notification.Builder(c, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentTitle(title).setContentText(text)
            .setAutoCancel(true).build()
        try { c.getSystemService(NotificationManager::class.java).notify(id.hashCode(), n) }
        catch (e: Throwable) { }
    }

    /** Notifica quando il livello scende sotto 20, 15, 10, 5 (una volta per soglia). */
    fun check(c: Context, id: String, level: Int, charging: Boolean) {
        if (level < 0) return
        if (charging) { Store.setThr(c, id, 101); return }
        val last = Store.thr(c, id)
        val bucket = T.filter { level <= it }.minOrNull() ?: 101
        if (bucket < last) {
            val name = Store.displayName(c, id)
            val txt = if (level <= 5) "Livello critico: ricaricalo subito!" else "Batteria in esaurimento."
            send(c, id, "🔋 $name al $level%", txt)
        }
        Store.setThr(c, id, bucket)
    }

    /** Notifica quando un dispositivo con batteria quasi scarica si spegne/disconnette. */
    fun off(c: Context, id: String, lastLevel: Int) {
        send(c, id + "_off", "⚫ ${Store.displayName(c, id)} si è spento",
            "Ultimo livello rilevato: $lastLevel%")
    }
}
