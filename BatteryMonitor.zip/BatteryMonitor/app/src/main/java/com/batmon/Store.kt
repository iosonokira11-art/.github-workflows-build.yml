package com.batmon

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

data class Entry(
    val id: String, val name: String, val level: Int, val connected: Boolean,
    val charging: Boolean, val emoji: String, val image: Bitmap?
)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("bm", Context.MODE_PRIVATE)

    fun ids(c: Context): List<String> =
        (p(c).getString("ids", "") ?: "").split("|").filter { it.isNotEmpty() }

    fun setIds(c: Context, l: List<String>) {
        p(c).edit().putString("ids", l.joinToString("|")).apply()
    }

    fun put(c: Context, id: String, name: String, level: Int, conn: Boolean, chg: Boolean, defEmoji: String) {
        p(c).edit().putString("n_$id", name).putInt("l_$id", level).putBoolean("c_$id", conn)
            .putBoolean("g_$id", chg).putString("de_$id", defEmoji).apply()
    }

    fun level(c: Context, id: String) = p(c).getInt("l_$id", -1)
    fun connected(c: Context, id: String) = p(c).getBoolean("c_$id", false)

    fun displayName(c: Context, id: String): String =
        p(c).getString("al_$id", null) ?: p(c).getString("n_$id", id) ?: id

    fun thr(c: Context, id: String) = p(c).getInt("t_$id", 101)
    fun setThr(c: Context, id: String, v: Int) { p(c).edit().putInt("t_$id", v).apply() }

    fun setAlias(c: Context, id: String, v: String?) = setStr(c, "al_$id", v)
    fun setEmoji(c: Context, id: String, v: String?) = setStr(c, "ce_$id", v)

    private fun setStr(c: Context, k: String, v: String?) {
        val e = p(c).edit()
        if (v.isNullOrBlank()) e.remove(k) else e.putString(k, v)
        e.apply()
    }

    fun imgFile(c: Context, id: String) =
        File(c.filesDir, "ico_" + id.replace(Regex("[^A-Za-z0-9]"), "_") + ".png")

    fun entries(c: Context): List<Entry> = ids(c).map { id ->
        val sp = p(c)
        val emoji = sp.getString("ce_$id", null) ?: sp.getString("de_$id", "🔵") ?: "🔵"
        val f = imgFile(c, id)
        val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        Entry(
            id, displayName(c, id), sp.getInt("l_$id", -1), sp.getBoolean("c_$id", false),
            sp.getBoolean("g_$id", false), emoji, bmp
        )
    }
}
