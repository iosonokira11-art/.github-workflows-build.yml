package com.batmon

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun bg(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }

    fun status(c: Context, e: Entry) = when {
        !e.connected -> "Non connesso"
        e.level < 0 -> "Batteria non comunicata (" + Store.err(c, e.id) + ")"
        e.charging -> "In carica"
        else -> "Connesso"
    }

    fun card(c: Context, e: Entry, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(c, 14), dp(c, 12), dp(c, 18), dp(c, 12))
            background = bg(0xFF151821.toInt(), dp(c, 22).toFloat())
            alpha = if (e.connected) 1f else 0.55f
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(c, 10)) }
        }
        row.addView(ImageView(c).apply { setImageBitmap(Render.ringBitmap(e, dp(c, 52))) },
            LinearLayout.LayoutParams(dp(c, 52), dp(c, 52)))
        val mid = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 14), 0, dp(c, 8), 0) }
        mid.addView(TextView(c).apply {
            text = e.name; textSize = 16f; setTextColor(0xFFF3F4F6.toInt())
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        mid.addView(TextView(c).apply { text = status(c, e); textSize = 12f; setTextColor(0xFF9CA3AF.toInt()) })
        row.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(c).apply {
            text = if (e.connected && e.level >= 0) "${e.level}%" else "—"
            textSize = 20f; setTextColor(Render.color(e)); typeface = Typeface.DEFAULT_BOLD
        })
        return row
    }
}
