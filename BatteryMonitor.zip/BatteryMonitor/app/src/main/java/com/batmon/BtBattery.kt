package com.batmon

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

object BtBattery {
    const val ACTION_BATT = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
    const val EXTRA_BATT = "android.bluetooth.device.extra.BATTERY_LEVEL"

    private fun hasPerm(c: Context) = Build.VERSION.SDK_INT < 31 ||
        c.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun bonded(c: Context): List<BluetoothDevice> {
        if (!hasPerm(c)) return emptyList()
        return try {
            val a = (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                ?: return emptyList()
            a.bondedDevices.toList()
        } catch (e: Throwable) { emptyList() }
    }

    /** Livello batteria riportato dal dispositivo (API nascosta, via reflection). -1 se non disponibile. */
    fun level(d: BluetoothDevice): Int = try {
        val v = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as Int
        if (v in 0..100) v else -1
    } catch (e: Throwable) { -1 }

    fun connected(d: BluetoothDevice): Boolean = try {
        BluetoothDevice::class.java.getMethod("isConnected").invoke(d) as Boolean
    } catch (e: Throwable) { false }

    @SuppressLint("MissingPermission")
    fun nameOf(d: BluetoothDevice): String = try { d.name ?: d.address } catch (e: Throwable) { d.address }

    /** Riconoscimento automatico dell'icona da classe Bluetooth e nome. */
    @SuppressLint("MissingPermission")
    fun defaultIcon(d: BluetoothDevice): String {
        val n = nameOf(d).lowercase()
        val c: BluetoothClass? = try { d.bluetoothClass } catch (e: Throwable) { null }
        if (n.contains("watch") || n.contains("band")) return "⌚"
        if (n.contains("buds") || n.contains("pods") || n.contains("earb")) return "🎧"
        if (n.contains("speaker") || n.contains("boom") || n.contains("soundbar")) return "🔊"
        if (n.contains("keyboard") || n.contains("tastiera")) return "⌨️"
        if (n.contains("mouse")) return "🖱️"
        if (n.contains("pen") || n.contains("stylus")) return "🖊️"
        if (c == null) return "🔵"
        return when (c.majorDeviceClass) {
            BluetoothClass.Device.Major.AUDIO_VIDEO -> when (c.deviceClass) {
                BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES,
                BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET,
                BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE -> "🎧"
                BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO -> "🚗"
                BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER,
                BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO,
                BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO -> "🔊"
                else -> "🎧"
            }
            BluetoothClass.Device.Major.PHONE -> "📱"
            BluetoothClass.Device.Major.COMPUTER -> "💻"
            BluetoothClass.Device.Major.WEARABLE -> "⌚"
            BluetoothClass.Device.Major.HEALTH -> "❤️"
            BluetoothClass.Device.Major.PERIPHERAL -> when (c.deviceClass) {
                BluetoothClass.Device.PERIPHERAL_KEYBOARD,
                BluetoothClass.Device.PERIPHERAL_KEYBOARD_POINTING -> "⌨️"
                BluetoothClass.Device.PERIPHERAL_POINTING -> "🖱️"
                else -> "🎮"
            }
            else -> "🔵"
        }
    }
}
