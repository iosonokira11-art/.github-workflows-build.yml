package com.batmon

import android.content.Context
import android.graphics.*

object Render {
    private fun aa() = Paint(Paint.ANTI_ALIAS_FLAG)

    fun color(e: Entry?): Int = when {
        e == null || !e.connected || e.level < 0 -> 0xFF6B7280.toInt()
        e.level > 50 -> 0xFF34D399.toInt()
        e.level > 20 -> 0xFFFBBF24.toInt()
        else -> 0xFFF87171.toInt()
    }

    private fun fit(p: Paint, text: String, maxW: Float) {
        while (p.measureText(text) > maxW && p.textSize > 8f) p.textSize -= 1f
    }

    /** Anello di progresso con icona/immagine al centro. */
    fun ring(cv: Canvas, e: Entry?, cx: Float, cy: Float, r: Float) {
        val sw = r * 0.26f
        val rr = r - sw / 2f
        val track = aa().apply { style = Paint.Style.STROKE; strokeWidth = sw; color = 0x24FFFFFF }
        cv.drawCircle(cx, cy, rr, track)
        if (e != null && e.connected && e.level >= 0) {
            val p = aa().apply {
                style = Paint.Style.STROKE; strokeWidth = sw; strokeCap = Paint.Cap.ROUND; color = color(e)
            }
            cv.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), -90f, maxOf(4f, 360f * e.level / 100f), false, p)
        }
        val ri = rr - sw * 0.9f
        val img = e?.image
        if (img != null) {
            val path = Path().apply { addCircle(cx, cy, ri, Path.Direction.CW) }
            cv.save(); cv.clipPath(path)
            cv.drawBitmap(img, null, RectF(cx - ri, cy - ri, cx + ri, cy + ri), aa().apply { isFilterBitmap = true })
            cv.restore()
        } else {
            val t = aa().apply { textSize = ri * 1.15f; textAlign = Paint.Align.CENTER }
            val fm = t.fontMetrics
            cv.drawText(e?.emoji ?: "🔋", cx, cy - (fm.ascent + fm.descent) / 2f, t)
        }
    }

    fun ringBitmap(e: Entry, px: Int): Bitmap {
        val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        ring(Canvas(b), e, px / 2f, px / 2f, px / 2f - 1f)
        return b
    }

    /** Disegna l'intero widget (un dispositivo) come immagine. */
    fun widget(c: Context, e: Entry?, w: Int, h: Int, d: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val wf = w.toFloat(); val hf = h.toFloat()
        val s = minOf(wf, hf)
        val rad = s * 0.26f
        cv.drawRoundRect(RectF(0f, 0f, wf, hf), rad, rad, aa().apply { color = 0xF2111318.toInt() })
        val bw = maxOf(1f, d * 0.8f)
        cv.drawRoundRect(RectF(bw / 2, bw / 2, wf - bw / 2, hf - bw / 2), rad, rad,
            aa().apply { style = Paint.Style.STROKE; strokeWidth = bw; color = 0x1AFFFFFF })

        if (e == null) {
            val t = aa().apply { color = 0xFF9CA3AF.toInt(); textAlign = Paint.Align.CENTER; textSize = s * 0.16f }
            fit(t, "Tocca per scegliere", wf * 0.85f)
            cv.drawText("Tocca per scegliere", wf / 2, hf / 2 + t.textSize / 3, t)
            return bmp
        }

        val pct = if (e.connected && e.level >= 0) "${e.level}%" + (if (e.charging) " ⚡" else "") else "—"
        val medium = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val bold = Typeface.create("sans-serif", Typeface.BOLD)

        if (wf > hf * 1.45f) {
            // layout orizzontale: anello a sinistra, nome + percentuale a destra
            val r = hf * 0.36f
            val cx = hf * 0.14f + r
            val cy = hf / 2f
            ring(cv, e, cx, cy, r)
            val tx = cx + r + hf * 0.16f
            val avail = wf - tx - hf * 0.12f
            val name = aa().apply { color = 0xFF9CA3AF.toInt(); typeface = medium; textSize = hf * 0.17f }
            val pp = aa().apply { color = if (e.connected) Color.WHITE else 0xFF6B7280.toInt(); typeface = bold; textSize = hf * 0.36f }
            fit(pp, pct, avail)
            val label = android.text.TextUtils.ellipsize(e.name, android.text.TextPaint(name), avail, android.text.TextUtils.TruncateAt.END).toString()
            cv.drawText(label, tx, cy - hf * 0.14f, name)
            cv.drawText(pct, tx, cy + hf * 0.22f, pp)
        } else {
            // layout compatto: anello sopra, percentuale sotto
            val r = s * 0.30f
            val gap = s * 0.10f
            val ps = s * 0.20f
            val top = (hf - (2 * r + gap + ps)) / 2f
            val cx = wf / 2f
            val cy = top + r
            ring(cv, e, cx, cy, r)
            val pp = aa().apply {
                color = if (e.connected) Color.WHITE else 0xFF6B7280.toInt()
                typeface = bold; textSize = ps; textAlign = Paint.Align.CENTER
            }
            fit(pp, pct, wf * 0.86f)
            cv.drawText(pct, cx, top + 2 * r + gap + ps * 0.8f, pp)
        }
        return bmp
    }
}
