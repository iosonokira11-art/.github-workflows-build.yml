package com.batmon

import android.app.Notification
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class MonitorService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 60_000) }
    }

    private val rcv = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            val dev = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> refreshPhone(i)
                BtBattery.ACTION_BATT -> if (dev != null) {
                    val lvl = i.getIntExtra(BtBattery.EXTRA_BATT, -1)
                    if (lvl in 0..100) {
                        val id = dev.address
                        Store.put(c, id, BtBattery.nameOf(dev), lvl, true, false, BtBattery.defaultIcon(dev))
                        if (!Store.ids(c).contains(id)) Store.setIds(c, Store.ids(c) + id)
                        Alerts.check(c, id, lvl, false)
                        BatteryWidget.updateAll(c)
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> h.postDelayed({ refresh() }, 4000)
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> if (dev != null) {
                    val id = dev.address
                    val last = Store.level(c, id)
                    if (Store.connected(c, id) && last in 0..10) Alerts.off(c, id, last)
                    Store.put(c, id, BtBattery.nameOf(dev), -1, false, false, BtBattery.defaultIcon(dev))
                    BatteryWidget.updateAll(c)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Alerts.channels(this)
        val n = Notification.Builder(this, Alerts.CH_MON)
            .setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentTitle("Monitor Batteria attivo").setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(1, n)
        } catch (e: Throwable) { stopSelf(); return }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(BtBattery.ACTION_BATT)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(rcv, f)
        h.post(tick)
    }

    private fun refreshPhone(bi: Intent) {
        val lv = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (lv < 0) return
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val pct = lv * 100 / sc
        Store.put(this, "phone", "Telefono", pct, true, chg, "📱")
        if (!Store.ids(this).contains("phone")) Store.setIds(this, listOf("phone") + Store.ids(this))
        Alerts.check(this, "phone", pct, chg)
        BatteryWidget.updateAll(this)
    }

    private fun refresh() {
        registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { refreshPhone(it) }
        val ids = ArrayList<String>()
        ids.add("phone")
        for (d in BtBattery.bonded(this)) {
            val id = d.address
            ids.add(id)
            val conn = BtBattery.connected(d)
            val prevConn = Store.connected(this, id)
            val prevLvl = Store.level(this, id)
            var lvl = if (conn) BtBattery.level(d) else -1
            if (conn) Store.setErr(this, id, BtBattery.lastErr)
            if (conn && lvl < 0 && prevConn) lvl = prevLvl // mantieni ultimo valore noto
            if (prevConn && !conn && prevLvl in 0..10) Alerts.off(this, id, prevLvl)
            Store.put(this, id, BtBattery.nameOf(d), lvl, conn, false, BtBattery.defaultIcon(d))
            if (conn) Alerts.check(this, id, lvl, false)
        }
        Store.setIds(this, ids)
        BatteryWidget.updateAll(this)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(rcv) } catch (e: Throwable) { }
        super.onDestroy()
    }
}
