# Monitor Batteria
Build APK: carica la cartella su GitHub (repo privato ok) -> Actions -> "Build APK" -> scarica artifact BatteryMonitor-apk.
Oppure apri in Android Studio e Build > Build APK.
